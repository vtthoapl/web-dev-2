
<footer class="footer p-10 bg-base-200 text-base-content mt-10 mb-0">
  <nav>
    <h6 class="footer-title">Company</h6> 
    <a href="/" class="link link-hover" alt="#">Home</a>
    <a href="/about" class="link link-hover" alt="#">About</a>
    <a href="/contact" class="link link-hover" alt="#">Contact</a>
    <a href="/chat" class="link link-hover" alt="#">Chat</a>
    <a href="/hero" class="link link-hover" alt="#">Hero</a>
    <a href="/carousel" class="link link-hover" alt="#">Carousel</a>
  </nav> 
  <nav>
    <h6 class="footer-title">Legal</h6> 
    <p class="link link-hover" >Terms of use</p>
    <p class="link link-hover" >Privacy policy</p>
    <p class="link link-hover" >Cookie policy</p>
  </nav> 
  <form>
    <h6 class="footer-title">Newsletter</h6> 
    <fieldset class="form-control w-80">
      <div class="join">
        <input type="text" placeholder="username@site.com" class="input input-bordered join-item" /> 
        <button class="btn btn-secondary join-item">Subscribe</button>
      </div>
    </fieldset>
  </form>
</footer>