<svelte:head>
    <title>About</title>
</svelte:head>

<h1>About</h1>
<p>This is my first Svelte & daidyUI application</p>