<svelte:head>
    <title>Chat</title>
</svelte:head>
<div class="chat chat-start mt-10">
    <div class="chat-image avatar">
      <div class="w-10 rounded-full">
        <img alt="Tailwind CSS chat bubble component" src="https://daisyui.com/images/stock/photo-1550258987-190a2d41a8ba.jpg" />
      </div>
    </div>
    <div class="chat-bubble">Hello Petteri</div>
  </div>
  <div class="chat chat-start">
    <div class="chat-image avatar">
      <div class="w-10 rounded-full">
        <img alt="Tailwind CSS chat bubble component" src="https://daisyui.com/images/stock/photo-1550258987-190a2d41a8ba.jpg" />
      </div>
    </div>
    <div class="chat-bubble">U should teach us React & typescript</div>
  </div>
  <div class="chat chat-start">
    <div class="chat-image avatar">
      <div class="w-10 rounded-full">
        <img alt="Tailwind CSS chat bubble component" src="https://daisyui.com/images/stock/photo-1550258987-190a2d41a8ba.jpg" />
      </div>
    </div>
    <div class="chat-bubble">But svelt is good too</div>
  </div>

  <style>
    .chat-bubble{
        background-color:rgb(185, 128, 177);
    }
  </style>