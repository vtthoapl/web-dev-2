<svelte:head>
    <title>Contact</title>
</svelte:head>

<h1>Contact</h1>
<p>Group 3: Irina, Deep, Hoa</p>