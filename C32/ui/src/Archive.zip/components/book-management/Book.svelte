<script>
    let { book } = $props();
  </script>
  
  <h1>Viewing a book:</h1>
  
  <p>Name: {book.name}</p>
  <p>Number of pages: {book.pages}</p>
  <p>ISBN: {book.isbn}</p>