<script>
    import BookList from '../components/book-management/BookList.svelte';
    import AddBook from '../components/book-management/AddBook.svelte';
  </script>
  
  <AddBook />
  <BookList />