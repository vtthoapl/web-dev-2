export const books = [
    { id: 1, name: "HP and the Philosopher's Stone", pages: 200, isbn: "123" },
    { id: 2, name: "HP and the Chamber of Secrets", pages: 250, isbn: "123" },
    { id: 3, name: "HP and the Prisoner of Azkaban", pages: 300, isbn: "123" },
    { id: 4, name: "HP and the Goblet of Fire", pages: 350, isbn: "123" },
    { id: 5, name: "HP and the Order of the Phoenix", pages: 400, isbn: "123" },
    { id: 6, name: "HP and the Half-Blood Prince", pages: 450, isbn: "123" },
    { id: 7, name: "HP and the Deathly Hallows", pages: 500, isbn: "123" }
  ];

  