<svelte:head>
  <title>Home</title>
</svelte:head>

<h1>Home</h1>
<p>This HOME page</p>