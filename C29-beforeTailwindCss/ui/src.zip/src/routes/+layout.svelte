<header>
    <h1>My application</h1>
</header>

<div>
    <slot />
</div>

<footer>
    <p>Chapter 29.1 - Assignment</p>
    <ul>
        <li><a href="/">Home</a></li>
        <li><a href="/about">About</a></li>
        <li><a href="/contact">Contact</a></li>
    </ul>
</footer>