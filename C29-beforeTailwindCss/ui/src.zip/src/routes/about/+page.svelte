<svelte:head>
    <title>About</title>
</svelte:head>

<h1>About</h1>
<p>This is chapter 29</p>